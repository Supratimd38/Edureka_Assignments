package com.hibernate;

public class HibernateTemplate {

}
