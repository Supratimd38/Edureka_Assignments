package com.hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Service;

@Service
public class MyService {
    @Autowired
    private HibernateTemplate hibernateTemplate;

    public void savePerson(Person person) {
        hibernateTemplate.save(person);
    }

    public Person getPersonById(int id) {
        return hibernateTemplate.get(Person.class, id);
    }

    public void updatePerson(Person person) {
        hibernateTemplate.update(person);
    }

    public void deletePerson(Person person) {
        hibernateTemplate.delete(person);
    }
}
