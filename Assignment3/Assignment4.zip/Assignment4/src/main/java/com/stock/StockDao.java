package com.stock;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;
import javax.sql.DataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

public class StockDao {
    private JdbcTemplate jdbcTemplate;

    public StockDao(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void insert(List<Stock> stocks) {
        String sql = "INSERT INTO stocks (id, name, price) VALUES (?, ?, ?)";
        jdbcTemplate.batchUpdate(sql, new BatchPreparedStatementSetter() {
            @Override
            public void setValues(PreparedStatement ps, int i) throws SQLException {
                Stock stock = stocks.get(i);
                ps.setInt(1, stock.getId());
                ps.setString(2, stock.getName());
                ps.setDouble(3, stock.getPrice());
            }

            @Override
            public int getBatchSize() {
                return stocks.size();
            }
        });
    }
}
