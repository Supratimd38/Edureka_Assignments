package com.stock;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainApp {
    public static void main(String[] args) {
        // Load the Spring configuration file
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Get the StockDao object from the Spring context
        StockDao dao = context.getBean("stockDao", StockDao.class);

        // Create 2000 Stock objects and add them to a list
        List<Stock> stocks = new ArrayList<>();
        Random random = new Random();
        for (int i = 1; i <= 2000; i++) {
            String name = "Stock" + i;
            double price = 10 + random.nextDouble() * 90; // Random price between 10 and 100
            Stock stock = new Stock(i, name, price);
            stocks.add(stock);
        }

        // Insert the stocks into the database using a batch insert operation
        dao.insert(stocks);

        // Print the number of stocks inserted
        System.out.println(stocks.size() + " stocks inserted into the database.");
    }
}
