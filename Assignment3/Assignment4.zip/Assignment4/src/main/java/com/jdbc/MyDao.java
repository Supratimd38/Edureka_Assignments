package com.jdbc;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

public class MyDao {
    private JdbcTemplate jdbcTemplate;

    public void setDataSource(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public List<Person> getPeople() {
        String sql = "SELECT * FROM people";
        RowMapper<Person> rowMapper = new PersonRowMapper();
        return jdbcTemplate.query(sql, rowMapper);
    }

    private static class PersonRowMapper implements RowMapper<Person> {
        public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
            int id = rs.getInt("id");
            String name = rs.getString("name");
            int age = rs.getInt("age");
            return new Person(id, name, age);
        }
    }
    public void insertData(Person person) {
        String sql = "INSERT INTO people (id, name, age) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, person.getId(), person.getName(), person.getAge());
    }
}
