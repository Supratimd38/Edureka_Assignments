package com.jdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Load the Spring configuration file
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        // Get the MyDao object from the Spring context
        MyDao dao = context.getBean("myDao", MyDao.class);

        // Insert a new Person object into the database
        dao.insertData(new Person(1, "Alice", 25));

        // Retrieve all Person objects from the database
        List<Person> people = dao.getPeople();

        // Print out the retrieved Person objects
        for (Person person : people) {
            System.out.println(person);
        }
    }
}
